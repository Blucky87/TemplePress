angular.module('app.controllers', [])
  
.controller('bookCtrl', function($scope, $http) {

    $scope.testPHP = function(){
        $http.get('otiose.io/php/test.php').then(function(response){
          console.log(response);
            $scope.testResult = "Success: [" + response +"]";
        },function(response){
          console.log(response);
            $scope.testResult = "Failed: [" + response + "]";
        });
    }

})
      
.controller('locationsCtrl', function($scope) {

})
   
.controller('cameraCtrl', function($scope) {

})
   
.controller('historicalSite1Ctrl', function($scope) {

})
   
.controller('historicalSite2Ctrl', function($scope) {

})
   
.controller('historicalSiteNCtrl', function($scope) {

})
   
.controller('loginCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope, $http) {
  $scope.inputForm = {
    name: "",
    email: "",    
    username: "",
    password: "",
    rpassword: ""
  }

  $scope.submittal = function(event){
    var $btn = $(event.currentTarget);
    var status = false;
    var data = $scope.inputForm.email;

    if($scope.inputForm.password != $scope.inputForm.rpassword && ($scope.inputForm.rpassword != "" || $scope.inputForm.password != "")){
      $('.pwd').toggleClass('failed', true);
      $('.pwd').toggleClass('succeed', false);
    }else {
      $('.pwd').toggleClass('succeed', true);
      $('.pwd').toggleClass('failed', false);        
    }

    $http.post('otiose.io/php/IsAvailable.php', data).then(function(response){
      if(reponse.data === "true")
        status = true;
        data = response.data;
    }, function(response){
      //onFail
    });    

    if(status){
      $scope.inputForm.name = data;
    }else{
      $scope.inputForm.name = data;
    }

  }

})
   
.controller('routesCtrl', function($scope) {
  $scope.wayPoints = [];
  $scope.navMode = "car";

  $scope.navSelectBtn = function(event){
    var $target = $(event.currentTarget);
    $scope.navMode = $target.attr('name');

    if(!$target.hasClass('button-calm')){
      $target.parent().find('.button-calm').toggleClass('button-positive',true);
      $target.parent().find('.button-calm').toggleClass('button-calm',false);
      $target.toggleClass('button-calm', true);
    }
  }

})

.controller('MyCtrl', function($scope, Camera) {
    $scope.photos = [];

    $scope.getPhoto = function() {
     Camera.getPicture().then(
      function(imageURI) {
        console.log(imageURI);
        $scope.photos.push(imageURI);
      }, 
      function(err) {
        console.err(err);
    });
  };



});
 